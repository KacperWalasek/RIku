asset_type="unit"
name = "peasant"
unit = {
    movement_points = 2000,
    miniunits = {
        "warrior",
        "warrior",
        "warrior",
    }
}
