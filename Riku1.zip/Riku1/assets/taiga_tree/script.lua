asset_type="tileobject"
name = "taiga_tree"

tileobject = {
    description = "taiga_tree",
    behavior = {
        unbuildable = {
            {
                a = ""
            }
        }
    }
}
