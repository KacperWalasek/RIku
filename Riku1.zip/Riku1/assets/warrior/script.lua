asset_type="unit"
name = "warrior"
unit = {
    movement_points = 2000,
    miniunits = {
        "warrior",
        "warrior",
        "warrior",
    }
}
