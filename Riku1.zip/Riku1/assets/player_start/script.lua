asset_type="tileobject"
name = "player_start"

tileobject = {
    description = "player_start",
    behavior = {
        unbuildable = {
            {
                a = ""
            }
        }
    }
}
