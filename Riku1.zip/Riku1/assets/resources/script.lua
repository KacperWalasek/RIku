asset_type = "resources"

resources = {
    'wood',
    'iron',
    'stone',
    'water'
}