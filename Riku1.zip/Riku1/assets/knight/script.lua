asset_type="unit"
name = "knight"
unit = {
    movement_points = 2000,
    miniunits = {
        "warrior",
        "warrior",
        "warrior",
    }
}
