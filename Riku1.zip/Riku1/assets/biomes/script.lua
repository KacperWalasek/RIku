asset_type="biomes"
biomes = {
    snow = 2.00,
    tundra = 1.50,
    taiga = 1.25,
    temperate = 1.00,
    mediterranean = 1.00,
    tropics = 1.25,
    sea = 1.00
}
