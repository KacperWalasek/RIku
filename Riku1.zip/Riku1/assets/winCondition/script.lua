asset_type="win_condition"

win_condition = {
    only_one_survived = {},
    enough_units = { 
        count = 10,
        name = "stefan"
    },
    enough_resources = {
        count = 50,
        name = "wood"
    }   
}