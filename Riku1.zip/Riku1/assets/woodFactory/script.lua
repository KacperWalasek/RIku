asset_type="tileobject"
name="wood_factory"

tileobject = {
    description = "wood_factory_description",
    behavior = {
        resource_factory = {
            {
                resource = "wood",
                quantity = 10
            }
        }
    }
}
