asset_type="tileobject"
name="well"

tileobject = {
    description = "well_description",
    behavior = {
        resource_factory = {
            {
                resource = "water",
                quantity = 10
            }
        }
    }
}