asset_type="tileobject"
name="cactus"
tileobject = {
    description = "cactus",
    behavior = {
        unbuildable = {
            {
                a = ""
            }
        }
    }
}
