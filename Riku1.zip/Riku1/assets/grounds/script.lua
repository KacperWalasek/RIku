asset_type="grounds"
grounds = {
    stone = 20,
    hot_desert = 30,
    semihot_desert = 25,
    cold_desert = 20,
    grass = 10,
    grass_tropics = 15,
    grass_taiga = 15,
    tundra = 20,
    snow = 40,
    water = 100000
}
