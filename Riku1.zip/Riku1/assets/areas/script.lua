asset_type="areas"
areas = {
    wet = 2,
    dry = 1.2
}