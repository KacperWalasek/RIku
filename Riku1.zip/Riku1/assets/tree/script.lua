asset_type="tileobject"
name = "tree"

tileobject = {
    description = "tree",
    behavior = {
        unbuildable = {
            {
                a = ""
            }
        }
    }
}
